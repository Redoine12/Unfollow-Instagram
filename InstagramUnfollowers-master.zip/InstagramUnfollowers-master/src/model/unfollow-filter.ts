export interface UnfollowFilter {
  readonly showSucceeded: boolean;
  readonly showFailed: boolean;
}
