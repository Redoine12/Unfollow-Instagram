export type ScanningTab = "non_whitelisted" | "whitelisted";
